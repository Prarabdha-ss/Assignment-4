module.exports = {
    url : "mongodb+srv://kinchu98sharma:Kinchu*11@prarabdha.uiht0ne.mongodb.net/"
};
